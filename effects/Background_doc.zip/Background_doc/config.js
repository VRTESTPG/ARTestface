Background = require('bnb_js/background');
Background.texture("test.jpeg")