Background = require('bnb_js/background');
Background.texture("Red.mp4")
Background.contentMode("fill")